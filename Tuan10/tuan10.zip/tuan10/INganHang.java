package tuan10;
interface INganHang 
{
    abstract void khoaChucNang(int thoiGianKhoa,String thongBao);
    abstract void hienThi();
    abstract double ThoiGianConLai();
} 
