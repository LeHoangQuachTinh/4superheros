package NHOM;
interface ICustomer {
    void placeOrder();
    void viewOrderStatus();
}
