package NHOM;
interface IRestaurant {
    void addDish();
    void updateDish();
    void deleteDish();
}