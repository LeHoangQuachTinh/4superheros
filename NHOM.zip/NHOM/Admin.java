package NHOM;

// Lớp Admin (Quản trị viên)

import java.util.HashMap;

public class Admin {
   HashMap<String,Restaurant> DS1;
   HashMap<String,Customer> DS2;

    public Admin() {
        this.DS1=new HashMap<>();
        this.DS2=new HashMap<>();
    }

   
}
